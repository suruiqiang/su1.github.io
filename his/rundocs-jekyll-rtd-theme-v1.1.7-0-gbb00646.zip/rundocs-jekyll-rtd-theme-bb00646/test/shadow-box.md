---
sort: 10
image: https://user-images.githubusercontent.com/68011645/89026666-ad3a8680-d35b-11ea-9f4b-d3fe26ae12ed.png
---

# Shadow-box Test
Add a class `shadow-box` with `{: .shadow-box }`

## With shadow-box
```
![]({{ page.image }}){: .shadow-box }
```
![]({{ page.image }}){: .shadow-box }


## Without shadow-box
```
![]({{ page.image }})
```
![]({{ page.image }})
